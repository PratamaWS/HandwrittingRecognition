package com.phatware.android;

//import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION =1;
    private static final String DATABASE_NAME = "HandwrittingManager";

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase){

    }
    @Override
    public void onUpgrade()
}
